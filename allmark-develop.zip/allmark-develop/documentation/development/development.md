# Development

allmark is open-source and you can just clone it and start adding your own features, improve existing ones, fix bugs, write tests or add missing documentation.

If you have any improvements for allmark please send me a pull request. All contributions are welcome.

---

created at: 2015-08-05
modified at: 2015-08-22
author: Andreas Koch
tags: Documentation, Development
alias: development, dev
